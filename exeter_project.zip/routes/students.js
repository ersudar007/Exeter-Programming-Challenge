const studentController = require('../controller/students');
const students = require('../Students');
const fs =require("fs");

const routes = [{
        method: 'GET',
        url: '/GET/report',
        handler: studentController.getAllStudents
    },
    {
        method: 'GET',
        url: '/GET/report/:id',
        handler: studentController.getStudent
    },
    {
        method: 'POST',
        url: '/POST/add',
        handler: studentController.addStudent
    },
    {
        method: 'POST',
        url: '/POST/update/:id',
        handler: studentController.updateStudent
    },
    {
        method: 'DELETE',
        url: '/DELETE/delete/:id',
        handler: studentController.deleteStudent
    }
]
module.exports = routes