let students= [
{
    StudentName:'student1',
    StudentID:1,
    Subjcet1:100,
    Subject2:98,
    Subject3:76,
    Subject4:82,
    Subject5:92

},
{
    StudentName:'student2',
    StudentID:2,
    Subjcet1:92,
    Subject2:100,
    Subject3:98,
    Subject4:76,
    Subject5:82
},
{
    StudentName:'student3',
    StudentID:3,
    Subjcet1:76,
    Subject2:92,
    Subject3:100,
    Subject4:98,
    Subject5:76
},
{
    StudentName:'student4',
    StudentID:4,
    Subjcet1:82,
    Subject2:76,
    Subject3:92,
    Subject4:100,
    Subject5:98
}

]
module.exports = students