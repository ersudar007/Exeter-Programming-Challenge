 const bodyParser = require('body-parser');
 let students = require('../Students');
 const fs =require("fs");


// let blogs = [
//     {
//         id: 1,
//         title: 'This is an experiment',
//         age:13
//     },
//     {
//         id: 2,
//         title: 'Fastify is pretty cool',
//         age:14
//     },
//     {
//         id: 3,
//         title: 'Just another blog, yea!'
//     }
// ]
// Handlers
const getAllStudents = async(req, reply) => {
    reply.send(students)
    
}

const getStudent = async (req, reply) => {
    const StudentID = Number(req.params.id) // blog ID
    const student = students.find(student => student.StudentID === StudentID)
    // return students
    reply.send(student)

}

const addStudent = async (req, reply) => {
    let {StudentName}= req.body
    const StudentID = students.length + 1 // generate new ID
    let {Subject1}=req.body
    let {Subject2}=req.body
    let {Subject3}=req.body
    let {Subject4}=req.body
    let {Subject5}=req.body

    const newStudent = {
        StudentName,
        StudentID,
        Subject1,
        Subject2,
        Subject3,
        Subject4,
        Subject5,
    
    }
    students.push(newStudent);
    reply.send(students);
    students=[...students, newStudent]
    return newStudent; 
    
    //let myobject=JSON.parse(data);
    //  students.push(newStudent);
    // var newdata=JSON.stringify(data);
   
}

const updateStudent = async (req, reply) => {
    let {StudentName}= req.body
    const StudentID = Number(req.params.id)
    let {Subject1}=req.body
    let {Subject2}=req.body
    let {Subject3}=req.body
    let {Subject4}=req.body
    let {Subject5}=req.body
students = students.map(student =>(student.StudentID === StudentID ? {StudentName,StudentID,Subject1,Subject2,Subject3,Subject4,
            Subject5}:student))
        student=students.find(student=>student.StudentID===StudentID);
        reply.send(student);
        


}

const deleteStudent = async (req, reply) => {
    const StudentID= Number(req.params.id)

    students = students.filter(student => student.StudentID !== StudentID)
    // return { msg: `student with ID ${id} is deleted` }
    reply.send ({ msg: `student with ID ${StudentID} is deleted` },students)
    
}

module.exports = {
    getAllStudents,
    getStudent,
    addStudent,
    updateStudent,
    deleteStudent
}