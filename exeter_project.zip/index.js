const fastify = require('fastify'); //Bring in Fastify
const students = require('./Students');
const PORT = process.env.PORT || 3000;
const app = fastify({
  logger: true
})
// Declare a route
app.get("/", async () => {
  return {
    Message: "Fastify is On Fire"
  }
})
// Register routes to handle blog posts
const studentRoutes = require('./routes/students')
studentRoutes.forEach((route, index) => {
    app.route(route)
})

//Funtion To run the server
const start = async () => {
  try {
    await app.listen(PORT)
    app.log.info(`server listening on ${app.server.address().port}`)
  } catch (err) {
    app.log.error(err)
    process.exit(1)
  }
}
start();